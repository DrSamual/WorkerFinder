package com.worker.finder.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    
    private SharedPreferences prefs;
    private SharedPreferences.Editor editor;
    private Context context;
    
    public SessionManager(Context context) {
        this.context = context;
        prefs = context.getSharedPreferences(Constants.PREF_NAME, Context.MODE_PRIVATE);
        editor = prefs.edit();
    }
    
    public void createLoginSession(String userId, String userType, 
                                   String name, String email, String phone) {
        editor.putBoolean(Constants.PREF_IS_LOGGED_IN, true);
        editor.putString(Constants.PREF_USER_ID, userId);
        editor.putString(Constants.PREF_USER_TYPE, userType);
        editor.putString(Constants.PREF_USER_NAME, name);
        editor.putString(Constants.PREF_USER_EMAIL, email);
        editor.putString(Constants.PREF_USER_PHONE, phone);
        editor.apply();
    }
    
    public boolean isLoggedIn() {
        return prefs.getBoolean(Constants.PREF_IS_LOGGED_IN, false);
    }
    
    public String getUserId() {
        return prefs.getString(Constants.PREF_USER_ID, null);
    }
    
    public String getUserType() {
        return prefs.getString(Constants.PREF_USER_TYPE, null);
    }
    
    public String getUserName() {
        return prefs.getString(Constants.PREF_USER_NAME, null);
    }
    
    public String getUserEmail() {
        return prefs.getString(Constants.PREF_USER_EMAIL, null);
    }
    
    public String getUserPhone() {
        return prefs.getString(Constants.PREF_USER_PHONE, null);
    }
    
    public void logout() {
        editor.clear();
        editor.apply();
    }
}