<?xml version="1.0" encoding="utf-8"?>
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@color/primary">

    <LinearLayout
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_centerInParent="true"
        android:orientation="vertical"
        android:gravity="center"
        android:padding="32dp">

        <de.hdodenhof.circleimageview.CircleImageView
            android:id="@+id/logoImage"
            android:layout_width="100dp"
            android:layout_height="100dp"
            android:src="@drawable/ic_person"
            android:background="@color/white"
            android:padding="20dp"
            android:layout_marginBottom="24dp"/>

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="WorkerFinder"
            android:textColor="@color/white"
            android:textSize="28sp"
            android:textStyle="bold"
            android:fontFamily="sans-serif-medium"/>

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="আপনার বিশ্বস্ত কর্মী খুঁজুন"
            android:textColor="#E0E0E0"
            android:textSize="14sp"
            android:layout_marginTop="8dp"/>

    </LinearLayout>

    <TextView
        android:id="@+id/developerText"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Created by Abdullah Al Galib"
        android:textColor="#BDBDBD"
        android:textSize="11sp"
        android:layout_alignParentBottom="true"
        android:layout_centerHorizontal="true"
        android:layout_marginBottom="50dp"/>

    <ProgressBar
        android:id="@+id/progressBar"
        android:layout_width="24dp"
        android:layout_height="24dp"
        android:layout_below="@id/developerText"
        android:layout_centerHorizontal="true"
        android:layout_marginTop="16dp"
        android:indeterminateTint="@color/white"/>

</RelativeLayout>