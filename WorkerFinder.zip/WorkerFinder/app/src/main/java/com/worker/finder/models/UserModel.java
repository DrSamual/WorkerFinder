package com.worker.finder.models;

public class UserModel {
    private String userId;
    private String fullName;
    private String email;
    private String phone;
    private String userType;      // client or worker
    private String profession;     // plumber, electrician etc.
    private String profileImage;   // ImageBB URL
    private String address;
    private String city;
    private String experience;
    private double rating;
    private int totalJobs;
    private boolean isVerified;
    private boolean isActive;
    private long createdAt;
    
    // Empty constructor (Firebase needs this)
    public UserModel() {}
    
    // Constructor for registration
    public UserModel(String userId, String fullName, String email, 
                     String phone, String userType) {
        this.userId = userId;
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
        this.userType = userType;
        this.rating = 0.0;
        this.totalJobs = 0;
        this.isVerified = false;
        this.isActive = true;
        this.createdAt = System.currentTimeMillis();
    }
    
    // Getters
    public String getUserId() { return userId; }
    public String getFullName() { return fullName; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public String getUserType() { return userType; }
    public String getProfession() { return profession; }
    public String getProfileImage() { return profileImage; }
    public String getAddress() { return address; }
    public String getCity() { return city; }
    public String getExperience() { return experience; }
    public double getRating() { return rating; }
    public int getTotalJobs() { return totalJobs; }
    public boolean isVerified() { return isVerified; }
    public boolean isActive() { return isActive; }
    public long getCreatedAt() { return createdAt; }
    
    // Setters
    public void setUserId(String userId) { this.userId = userId; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public void setEmail(String email) { this.email = email; }
    public void setPhone(String phone) { this.phone = phone; }
    public void setUserType(String userType) { this.userType = userType; }
    public void setProfession(String profession) { this.profession = profession; }
    public void setProfileImage(String profileImage) { this.profileImage = profileImage; }
    public void setAddress(String address) { this.address = address; }
    public void setCity(String city) { this.city = city; }
    public void setExperience(String experience) { this.experience = experience; }
    public void setRating(double rating) { this.rating = rating; }
    public void setTotalJobs(int totalJobs) { this.totalJobs = totalJobs; }
    public void setVerified(boolean verified) { isVerified = verified; }
    public void setActive(boolean active) { isActive = active; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
}