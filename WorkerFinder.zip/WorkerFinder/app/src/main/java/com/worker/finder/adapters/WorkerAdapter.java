package com.worker.finder.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.worker.finder.R;
import com.worker.finder.activities.WorkerDetailsActivity;
import com.worker.finder.models.UserModel;
import java.util.List;
import de.hdodenhof.circleimageview.CircleImageView;

public class WorkerAdapter extends RecyclerView.Adapter<WorkerAdapter.ViewHolder> {
    
    private Context context;
    private List<UserModel> workerList;
    
    public WorkerAdapter(Context context, List<UserModel> workerList) {
        this.context = context;
        this.workerList = workerList;
    }
    
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
            .inflate(R.layout.item_worker, parent, false);
        return new ViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        UserModel worker = workerList.get(position);
        holder.nameText.setText(worker.getFullName());
        holder.professionText.setText(worker.getProfession());
        holder.ratingBar.setRating((float) worker.getRating());
        holder.jobsText.setText(worker.getTotalOrders() + " টি কাজ");
        
        holder.bookButton.setOnClickListener(v -> {
            Intent intent = new Intent(context, WorkerDetailsActivity.class);
            intent.putExtra("workerId", worker.getUserId());
            intent.putExtra("workerName", worker.getFullName());
            intent.putExtra("workerProfession", worker.getProfession());
            context.startActivity(intent);
        });
    }
    
    @Override
    public int getItemCount() {
        return workerList.size();
    }
    
    public void updateList(List<UserModel> newList) {
        workerList.clear();
        workerList.addAll(newList);
        notifyDataSetChanged();
    }
    
    public static class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView profileImage;
        TextView nameText, professionText, jobsText;
        RatingBar ratingBar;
        Button bookButton;
        
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            profileImage = itemView.findViewById(R.id.workerImage);
            nameText = itemView.findViewById(R.id.workerName);
            professionText = itemView.findViewById(R.id.workerProfession);
            ratingBar = itemView.findViewById(R.id.workerRating);
            jobsText = itemView.findViewById(R.id.workerJobs);
            bookButton = itemView.findViewById(R.id.bookButton);
        }
    }
}