package com.worker.finder.utils;

public class Constants {
    
    // Firebase Collections
    public static final String USERS = "users";
    public static final String PROFESSIONS = "professions";
    public static final String ORDERS = "orders";
    public static final String PAYMENTS = "payments";
    public static final String REVIEWS = "reviews";
    public static final String SETTINGS = "settings";
    
    // User Types
    public static final String USER_GRAAHOK = "গ্রাহক";
    public static final String USER_KORMI = "কর্মী";
    public static final String USER_ADMIN = "admin";
    
    // Order Status
    public static final String STATUS_PENDING = "অপেক্ষমাণ";
    public static final String STATUS_ACCEPTED = "গৃহীত";
    public static final String STATUS_IN_PROGRESS = "চলমান";
    public static final String STATUS_COMPLETED = "সম্পন্ন";
    public static final String STATUS_CANCELLED = "বাতিল";
    
    // Payment Status
    public static final String PAYMENT_PENDING = "অপেক্ষমাণ";
    public static final String PAYMENT_APPROVED = "অনুমোদিত";
    public static final String PAYMENT_REJECTED = "বাতিল";
    public static final String PAYMENT_RELEASED = "রিলিজ হয়েছে";
    
    // Payment Methods
    public static final String PAYMENT_BKASH = "বিকাশ";
    public static final String PAYMENT_NOGOD = "নগদ";
    public static final String PAYMENT_ROCKET = "রকেট";
    
    // Order Types
    public static final String ORDER_NORMAL = "সাধারণ";
    public static final String ORDER_EMERGENCY = "জরুরি";
    
    // ImageBB API
    public static final String IMGBB_API_KEY = "d6605371427bc39747271370135af03b";
    
    // Shared Preferences
    public static final String PREF_NAME = "WorkerFinder";
    public static final String PREF_USER_ID = "userId";
    public static final String PREF_USER_TYPE = "userType";
    public static final String PREF_IS_LOGGED_IN = "isLoggedIn";
    public static final String PREF_USER_NAME = "userName";
    public static final String PREF_USER_EMAIL = "userEmail";
    public static final String PREF_USER_PHONE = "userPhone";
}