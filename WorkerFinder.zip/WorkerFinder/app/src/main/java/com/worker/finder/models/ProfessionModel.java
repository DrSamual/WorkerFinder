package com.worker.finder.models;

public class ProfessionModel {
    private String professionId;
    private String name;          // প্লাম্বার, ইলেকট্রিশিয়ান
    private String nameEnglish;   // Plumber, Electrician
    private String icon;          // ImageBB URL for icon
    private boolean isActive;
    private long createdAt;
    
    public ProfessionModel() {}
    
    public ProfessionModel(String professionId, String name, String nameEnglish) {
        this.professionId = professionId;
        this.name = name;
        this.nameEnglish = nameEnglish;
        this.isActive = true;
        this.createdAt = System.currentTimeMillis();
    }
    
    public String getProfessionId() { return professionId; }
    public void setProfessionId(String professionId) { this.professionId = professionId; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getNameEnglish() { return nameEnglish; }
    public void setNameEnglish(String nameEnglish) { this.nameEnglish = nameEnglish; }
    
    public String getIcon() { return icon; }
    public void setIcon(String icon) { this.icon = icon; }
    
    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }
    
    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
}