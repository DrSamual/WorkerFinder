package com.worker.finder.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.worker.finder.R;
import com.worker.finder.fragments.HomeFragment;
import com.worker.finder.fragments.OrdersFragment;
import com.worker.finder.fragments.ProfileFragment;
import com.worker.finder.fragments.SearchFragment;
import com.worker.finder.utils.SessionManager;

public class MainActivity extends AppCompatActivity {
    
    private BottomNavigationView bottomNavigation;
    private SessionManager sessionManager;
    private FirebaseAuth mAuth;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        sessionManager = new SessionManager(this);
        mAuth = FirebaseAuth.getInstance();
        
        bottomNavigation = findViewById(R.id.bottomNavigation);
        
        // Default fragment
        loadFragment(new HomeFragment());
        
        bottomNavigation.setOnNavigationItemSelectedListener(
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Fragment fragment = null;
                    
                    int id = item.getItemId();
                    if (id == R.id.navHome) {
                        fragment = new HomeFragment();
                    } else if (id == R.id.navSearch) {
                        fragment = new SearchFragment();
                    } else if (id == R.id.navOrders) {
                        fragment = new OrdersFragment();
                    } else if (id == R.id.navProfile) {
                        fragment = new ProfileFragment();
                    }
                    
                    if (fragment != null) {
                        loadFragment(fragment);
                    }
                    return true;
                }
            });
    }
    
    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit();
    }
}