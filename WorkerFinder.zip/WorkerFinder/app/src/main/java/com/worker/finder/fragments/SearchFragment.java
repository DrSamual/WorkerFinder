package com.worker.finder.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.worker.finder.R;
import com.worker.finder.adapters.WorkerAdapter;
import com.worker.finder.models.UserModel;
import com.worker.finder.utils.Constants;
import java.util.ArrayList;
import java.util.List;

public class SearchFragment extends Fragment {
    
    private SearchView searchView;
    private Spinner citySpinner;
    private RecyclerView workersRecyclerView;
    private TextView resultCount;
    private FirebaseFirestore db;
    private List<UserModel> workerList;
    private WorkerAdapter workerAdapter;
    
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, 
                             @Nullable ViewGroup container, 
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);
        
        db = FirebaseFirestore.getInstance();
        
        searchView = view.findViewById(R.id.searchView);
        citySpinner = view.findViewById(R.id.citySpinner);
        workersRecyclerView = view.findViewById(R.id.workersRecyclerView);
        resultCount = view.findViewById(R.id.resultCount);
        
        workerList = new ArrayList<>();
        workerAdapter = new WorkerAdapter(getContext(), workerList);
        workersRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        workersRecyclerView.setAdapter(workerAdapter);
        
        // Search listener
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                searchWorkers(query);
                return true;
            }
            
            @Override
            public boolean onQueryTextChange(String newText) {
                if (newText.length() >= 2) {
                    searchWorkers(newText);
                } else if (newText.isEmpty()) {
                    loadAllWorkers();
                }
                return true;
            }
        });
        
        loadAllWorkers();
        
        return view;
    }
    
    private void loadAllWorkers() {
        db.collection(Constants.USERS)
            .whereEqualTo("userType", Constants.USER_KORMI)
            .whereEqualTo("isActive", true)
            .orderBy("rating", Query.Direction.DESCENDING)
            .get()
            .addOnSuccessListener(queryDocumentSnapshots -> {
                workerList.clear();
                for (DocumentSnapshot doc : queryDocumentSnapshots) {
                    UserModel worker = doc.toObject(UserModel.class);
                    if (worker != null) {
                        workerList.add(worker);
                    }
                }
                workerAdapter.notifyDataSetChanged();
                resultCount.setText("মোট " + workerList.size() + " জন কর্মী");
            })
            .addOnFailureListener(e -> {
                Toast.makeText(getContext(), 
                    "কর্মী লোড করতে সমস্যা হয়েছে", Toast.LENGTH_SHORT).show();
            });
    }
    
    private void searchWorkers(String query) {
        String searchQuery = query.toLowerCase();
        List<UserModel> filtered = new ArrayList<>();
        
        for (UserModel worker : workerList) {
            if (worker.getFullName() != null && 
                worker.getFullName().toLowerCase().contains(searchQuery)) {
                filtered.add(worker);
            } else if (worker.getProfession() != null && 
                       worker.getProfession().toLowerCase().contains(searchQuery)) {
                filtered.add(worker);
            } else if (worker.getCity() != null && 
                       worker.getCity().toLowerCase().contains(searchQuery)) {
                filtered.add(worker);
            }
        }
        
        workerAdapter.updateList(filtered);
        resultCount.setText("পাওয়া গেছে " + filtered.size() + " জন");
    }
}