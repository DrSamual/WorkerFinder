package com.worker.finder.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.worker.finder.R;
import com.worker.finder.adapters.OrderAdapter;
import com.worker.finder.models.OrderModel;
import com.worker.finder.utils.Constants;
import com.worker.finder.utils.SessionManager;
import java.util.ArrayList;
import java.util.List;

public class OrdersFragment extends Fragment {
    
    private RecyclerView ordersRecyclerView;
    private FirebaseFirestore db;
    private SessionManager sessionManager;
    private List<OrderModel> orderList;
    private OrderAdapter orderAdapter;
    
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, 
                             @Nullable ViewGroup container, 
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_orders, container, false);
        
        // Simple layout for now (will enhance later)
        ordersRecyclerView = new RecyclerView(getContext());
        ordersRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        
        db = FirebaseFirestore.getInstance();
        sessionManager = new SessionManager(getContext());
        
        orderList = new ArrayList<>();
        orderAdapter = new OrderAdapter(getContext(), orderList);
        ordersRecyclerView.setAdapter(orderAdapter);
        
        loadOrders();
        
        return ordersRecyclerView;
    }
    
    private void loadOrders() {
        String userId = sessionManager.getUserId();
        String userType = sessionManager.getUserType();
        
        Query query;
        if (userType.equals(Constants.USER_GRAAHOK)) {
            query = db.collection(Constants.ORDERS)
                .whereEqualTo("customerId", userId)
                .orderBy("createdAt", Query.Direction.DESCENDING);
        } else {
            query = db.collection(Constants.ORDERS)
                .whereEqualTo("workerId", userId)
                .orderBy("createdAt", Query.Direction.DESCENDING);
        }
        
        query.get()
            .addOnSuccessListener(queryDocumentSnapshots -> {
                orderList.clear();
                for (DocumentSnapshot doc : queryDocumentSnapshots) {
                    OrderModel order = doc.toObject(OrderModel.class);
                    if (order != null) {
                        orderList.add(order);
                    }
                }
                orderAdapter.notifyDataSetChanged();
            });
    }
}