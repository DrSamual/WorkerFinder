package com.worker.finder.models;

public class OrderModel {

}
