package com.worker.finder.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.worker.finder.R;
import com.worker.finder.models.UserModel;
import com.worker.finder.utils.Constants;
import com.worker.finder.utils.SessionManager;
import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {
    
    private TextInputEditText nameInput, emailInput, phoneInput, passwordInput;
    private RadioGroup userTypeGroup;
    private RadioButton radioCustomer, radioWorker;
    private TextInputLayout professionLayout;
    private Spinner professionSpinner;
    private MaterialButton registerButton;
    private ProgressBar progressBar;
    
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private SessionManager sessionManager;
    
    private String[] professions = {
        "প্লাম্বার", "ইলেকট্রিশিয়ান", "রাজমিস্ত্রি", "সার্ভেয়ার",
        "পেইন্টার", "কাঠমিস্ত্রি", "পরিচ্ছন্নতাকর্মী", "মেকানিক",
        "ড্রাইভার", "মালী"
    };
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        sessionManager = new SessionManager(this);
        
        // Find views
        nameInput = findViewById(R.id.nameInput);
        emailInput = findViewById(R.id.emailInput);
        phoneInput = findViewById(R.id.phoneInput);
        passwordInput = findViewById(R.id.passwordInput);
        userTypeGroup = findViewById(R.id.userTypeGroup);
        radioCustomer = findViewById(R.id.radioCustomer);
        radioWorker = findViewById(R.id.radioWorker);
        professionLayout = findViewById(R.id.professionLayout);
        professionSpinner = findViewById(R.id.professionSpinner);
        registerButton = findViewById(R.id.registerButton);
        progressBar = findViewById(R.id.progressBar);
        
        // Profession spinner setup
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_item, professions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        professionSpinner.setAdapter(adapter);
        
        // Check if Google sign-in data
        if (getIntent().hasExtra("google_email")) {
            emailInput.setText(getIntent().getStringExtra("google_email"));
            nameInput.setText(getIntent().getStringExtra("google_name"));
        }
        
        // User type change listener
        userTypeGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radioWorker) {
                    professionLayout.setVisibility(View.VISIBLE);
                } else {
                    professionLayout.setVisibility(View.GONE);
                }
            }
        });
        
        // Register button click
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });
        
        // Login link
        findViewById(R.id.loginLink).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                finish();
            }
        });
    }
    
    private void registerUser() {
        String name = nameInput.getText().toString().trim();
        String email = emailInput.getText().toString().trim();
        String phone = phoneInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();
        
        // Validation
        if (TextUtils.isEmpty(name)) {
            nameInput.setError("নাম লিখুন");
            return;
        }
        
        if (TextUtils.isEmpty(email)) {
            emailInput.setError("ইমেইল লিখুন");
            return;
        }
        
        if (TextUtils.isEmpty(phone)) {
            phoneInput.setError("ফোন নম্বর লিখুন");
            return;
        }
        
        if (phone.length() != 11) {
            phoneInput.setError("সঠিক ফোন নম্বর লিখুন (১১ ডিজিট)");
            return;
        }
        
        if (TextUtils.isEmpty(password)) {
            passwordInput.setError("পাসওয়ার্ড লিখুন");
            return;
        }
        
        if (password.length() < 6) {
            passwordInput.setError("পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে");
            return;
        }
        
        if (userTypeGroup.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, "গ্রাহক বা কর্মী সিলেক্ট করুন", Toast.LENGTH_SHORT).show();
            return;
        }
        
        String userType = radioWorker.isChecked() ? Constants.USER_KORMI : Constants.USER_GRAAHOK;
        String profession = "";
        
        if (radioWorker.isChecked()) {
            profession = professionSpinner.getSelectedItem().toString();
        }
        
        showProgress(true);
        
        final String finalProfession = profession;
        mAuth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        String userId = mAuth.getCurrentUser().getUid();
                        saveUserData(userId, name, email, phone, userType, finalProfession);
                    } else {
                        showProgress(false);
                        String error = task.getException() != null ? 
                            task.getException().getMessage() : "নিবন্ধন ব্যর্থ";
                        Toast.makeText(RegisterActivity.this, error, Toast.LENGTH_SHORT).show();
                    }
                }
            });
    }
    
    private void saveUserData(String userId, String name, String email, 
                              String phone, String userType, String profession) {
        Map<String, Object> userData = new HashMap<>();
        userData.put("userId", userId);
        userData.put("fullName", name);
        userData.put("email", email);
        userData.put("phone", phone);
        userData.put("userType", userType);
        userData.put("profession", profession);
        userData.put("profileImage", "");
        userData.put("address", "");
        userData.put("city", "ঢাকা");
        userData.put("experience", "");
        userData.put("rating", 0.0);
        userData.put("totalOrders", 0);
        userData.put("totalEarnings", 0.0);
        userData.put("isVerified", false);
        userData.put("isActive", true);
        userData.put("createdAt", System.currentTimeMillis());
        
        db.collection(Constants.USERS).document(userId)
            .set(userData)
            .addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    showProgress(false);
                    if (task.isSuccessful()) {
                        sessionManager.createLoginSession(userId, userType, name, email, phone);
                        Toast.makeText(RegisterActivity.this, 
                            "নিবন্ধন সফল হয়েছে!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(RegisterActivity.this, MainActivity.class));
                        finish();
                    } else {
                        Toast.makeText(RegisterActivity.this, 
                            "তথ্য সংরক্ষণ ব্যর্থ", Toast.LENGTH_SHORT).show();
                    }
                }
            });
    }
    
    private void showProgress(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        registerButton.setEnabled(!show);
    }
}