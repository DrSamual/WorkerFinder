package com.worker.finder.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.worker.finder.R;
import com.worker.finder.activities.WorkerDetailsActivity;
import java.util.List;

public class ProfessionAdapter extends RecyclerView.Adapter<ProfessionAdapter.ViewHolder> {
    
    private Context context;
    private List<String> professionList;
    
    public ProfessionAdapter(Context context, List<String> professionList) {
        this.context = context;
        this.professionList = professionList;
    }
    
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
            .inflate(android.R.layout.simple_list_item_1, parent, false);
        return new ViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String profession = professionList.get(position);
        holder.textView.setText(profession);
        holder.textView.setOnClickListener(v -> {
            // Search workers by profession
        });
    }
    
    @Override
    public int getItemCount() {
        return professionList.size();
    }
    
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(android.R.id.text1);
        }
    }
}