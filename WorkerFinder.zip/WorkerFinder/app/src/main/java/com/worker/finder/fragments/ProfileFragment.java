package com.worker.finder.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.firebase.auth.FirebaseAuth;
import com.worker.finder.R;
import com.worker.finder.activities.LoginActivity;
import com.worker.finder.activities.ProfileEditActivity;
import com.worker.finder.utils.SessionManager;
import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileFragment extends Fragment {
    
    private CircleImageView profileImage;
    private TextView profileName, profileType, profilePhone;
    private TextView editProfileBtn, aboutBtn, logoutBtn;
    private SessionManager sessionManager;
    private FirebaseAuth mAuth;
    
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, 
                             @Nullable ViewGroup container, 
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        
        sessionManager = new SessionManager(getContext());
        mAuth = FirebaseAuth.getInstance();
        
        profileImage = view.findViewById(R.id.profileImage);
        profileName = view.findViewById(R.id.profileName);
        profileType = view.findViewById(R.id.profileType);
        profilePhone = view.findViewById(R.id.profilePhone);
        editProfileBtn = view.findViewById(R.id.editProfileBtn);
        aboutBtn = view.findViewById(R.id.aboutBtn);
        logoutBtn = view.findViewById(R.id.logoutBtn);
        
        // Load user data
        profileName.setText(sessionManager.getUserName());
        profileType.setText(sessionManager.getUserType());
        profilePhone.setText(sessionManager.getUserPhone());
        
        // Edit profile
        editProfileBtn.setOnClickListener(v -> {
            startActivity(new Intent(getActivity(), ProfileEditActivity.class));
        });
        
        // Logout
        logoutBtn.setOnClickListener(v -> {
            mAuth.signOut();
            sessionManager.logout();
            Intent intent = new Intent(getActivity(), LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            if (getActivity() != null) {
                getActivity().finish();
            }
            Toast.makeText(getContext(), "সফলভাবে বের হয়েছেন", Toast.LENGTH_SHORT).show();
        });
        
        return view;
    }
}