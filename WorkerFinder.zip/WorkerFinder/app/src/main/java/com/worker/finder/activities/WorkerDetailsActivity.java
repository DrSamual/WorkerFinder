package com.worker.finder.activities;

public class WorkerDetailsActivity {

}
