package com.worker.finder.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.worker.finder.R;
import com.worker.finder.models.OrderModel;
import java.util.List;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.ViewHolder> {
    
    private Context context;
    private List<OrderModel> orderList;
    
    public OrderAdapter(Context context, List<OrderModel> orderList) {
        this.context = context;
        this.orderList = orderList;
    }
    
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
            .inflate(R.layout.item_order, parent, false);
        return new ViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        OrderModel order = orderList.get(position);
        holder.professionText.setText(order.getProfession());
        holder.dateText.setText(order.getDate());
        holder.amountText.setText("৳" + order.getAmount());
        holder.statusText.setText(order.getStatus());
        holder.addressText.setText(order.getAddress());
    }
    
    @Override
    public int getItemCount() {
        return orderList.size();
    }
    
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView professionText, dateText, amountText, statusText, addressText;
        
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            professionText = itemView.findViewById(R.id.orderProfession);
            dateText = itemView.findViewById(R.id.orderDate);
            amountText = itemView.findViewById(R.id.orderAmount);
            statusText = itemView.findViewById(R.id.orderStatus);
            addressText = itemView.findViewById(R.id.orderAddress);
        }
    }
}