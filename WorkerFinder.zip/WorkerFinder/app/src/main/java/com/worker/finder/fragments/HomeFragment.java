package com.worker.finder.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.worker.finder.R;
import com.worker.finder.activities.EmergencyOrderActivity;
import com.worker.finder.adapters.ProfessionAdapter;
import com.worker.finder.adapters.WorkerAdapter;
import com.worker.finder.models.UserModel;
import com.worker.finder.utils.Constants;
import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {
    
    private RecyclerView professionRecyclerView, topWorkersRecyclerView;
    private CardView emergencyCard;
    private FirebaseFirestore db;
    private List<String> professionList;
    private List<UserModel> workerList;
    private ProfessionAdapter professionAdapter;
    private WorkerAdapter workerAdapter;
    
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, 
                             @Nullable ViewGroup container, 
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        
        db = FirebaseFirestore.getInstance();
        
        professionRecyclerView = view.findViewById(R.id.professionRecyclerView);
        topWorkersRecyclerView = view.findViewById(R.id.topWorkersRecyclerView);
        emergencyCard = view.findViewById(R.id.emergencyCard);
        
        // Profession list
        professionList = new ArrayList<>();
        professionAdapter = new ProfessionAdapter(getContext(), professionList);
        professionRecyclerView.setLayoutManager(new GridLayoutManager(getContext(), 3));
        professionRecyclerView.setAdapter(professionAdapter);
        
        // Workers list
        workerList = new ArrayList<>();
        workerAdapter = new WorkerAdapter(getContext(), workerList);
        topWorkersRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        topWorkersRecyclerView.setAdapter(workerAdapter);
        
        // Emergency button click
        emergencyCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), EmergencyOrderActivity.class));
            }
        });
        
        loadProfessions();
        loadTopWorkers();
        
        return view;
    }
    
    private void loadProfessions() {
        String[] profs = {
            "প্লাম্বার", "ইলেকট্রিশিয়ান", "রাজমিস্ত্রি", 
            "সার্ভেয়ার", "পেইন্টার", "কাঠমিস্ত্রি",
            "পরিচ্ছন্নতাকর্মী", "মেকানিক", "ড্রাইভার", "মালী"
        };
        
        for (String p : profs) {
            professionList.add(p);
        }
        professionAdapter.notifyDataSetChanged();
    }
    
    private void loadTopWorkers() {
        db.collection(Constants.USERS)
            .whereEqualTo("userType", Constants.USER_KORMI)
            .whereEqualTo("isActive", true)
            .orderBy("rating", Query.Direction.DESCENDING)
            .limit(10)
            .get()
            .addOnSuccessListener(queryDocumentSnapshots -> {
                workerList.clear();
                for (DocumentSnapshot doc : queryDocumentSnapshots) {
                    UserModel worker = doc.toObject(UserModel.class);
                    if (worker != null) {
                        workerList.add(worker);
                    }
                }
                workerAdapter.notifyDataSetChanged();
            })
            .addOnFailureListener(e -> {
                Toast.makeText(getContext(), 
                    "কর্মী লোড করতে সমস্যা হয়েছে", Toast.LENGTH_SHORT).show();
            });
    }
}